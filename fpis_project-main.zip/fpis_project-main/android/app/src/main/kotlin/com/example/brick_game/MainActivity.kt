package com.example.brick_game

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
